copy BOOKS FROM 'C:\Program Files\PostgreSQL\18\data\books.csv' CSV HEADER;
SELECT * FROM BOOKS;